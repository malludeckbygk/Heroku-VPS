# vps-heroku
so this is another file for heroku vps and its kinda same as pervious one

here is the link to make ur vps
https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2FRixEtte%2Fvps-heroku
